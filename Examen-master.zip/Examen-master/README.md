# 15 Puzzle - Examen de Programacion Avanzada
## Juan Pablo de Jesus Figueroa Jaramillo

![Screen 5](/art/puzzle.png)

# Juego del 15

El juego del 15 o taken es un juego de deslizamiento de piezas que presentan un determinado orden inicial dentro de una cajita cuadrada. Tiene su origen en Estados Unidos, en el siglo XIX. 

# Juego

El taken es una cajita formada por 16 casillas de las cuales sólo quince están ocupadas. Todas las fichas están colocadas en orden numérico, excepto la 14 y la 15, que tienen sus posiciones intercambiadas. El juego consiste en maniobrar todas las fichas para corregir el error que hay en la fila inferior de la cajita, de manera que todas las fichas queden en orden consecutivo. 

# La fiebre del taken

Entre 1880 y 1882, el juego del 15 se convirtió en una verdadera plaga social que se extendió por Estados Unidos y Europa. Sin embargo en 1882, se descubrió que de todos los problemas propuestos en el juego, sólo la mitad tenían solución. En los periódicos se publicaron anuncios de recompensas a quien resolviera por lo menos uno de los problemas insolucionables y diversos diarios neoyorquinos ofrecieron 1.000 dólares al resolutor. Nadie ganó el premio. El juego acabó por desilusionar a la población y con ello terminó la fiebre del taken. 


	
